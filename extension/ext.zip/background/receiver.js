
// Private 
// var  burl  = 'http://localhost:8080';
var  burl  = 'http://nodejs-mongo-persistent-wh-nodejs-2.7e14.starter-us-west-2.openshiftapps.com';

function httpPost(path, body, callback) {

  var xmlhttp = new XMLHttpRequest(); 

  function reqListener () {
         var _this = this;
         callback(_this.responseText);
  }

  xmlhttp.addEventListener('load', reqListener);
  xmlhttp.open('POST', burl + path);
  xmlhttp.setRequestHeader('Content-Type', 'application/json');
  xmlhttp.send(JSON.stringify(body));

}

function httpGet(path, body, callback) { 

     var xmlhttp = new XMLHttpRequest();

    function reqListener () {
         var _this = this;
         callback(_this.responseText);
    }

    xmlhttp = new XMLHttpRequest();
    xmlhttp.addEventListener('load', reqListener);
    xmlhttp.open('GET', burl + path);
    xmlhttp.send();
  
}

// Main 
chrome.runtime.onMessage.addListener(

  function(request, sender, sendResponse) {

  	var tabId;

  	tabId = sender.tab.id;

  	if(request.cs) {

    httpGet('/content_script/main.js', null, function(response){
       chrome.tabs.executeScript(tabId, {code: response}, function(res){
            console.log(res);
        });
    });

  	} else if(request.genKey) {
    
    httpPost('/gen_key', {os: request.os, agent:request.agent}, function(response){
       var obj = JSON.parse(response);
       chrome.storage.sync.set({'snfkey': obj.key}, function() {
          sendResponse(obj.key);
       });
    });

    } else if(request.body && request.body.url && request.body.url.indexOf(burl) == -1) {

    httpPost('/webhook', request.body, function(response) {
        console.log(response);
    });

  	}
  
});