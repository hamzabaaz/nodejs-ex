(function(){

chrome.runtime.sendMessage({
  	cs: true
});

}());